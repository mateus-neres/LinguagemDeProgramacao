public interface VendaDeTurismoIF {
    double getPreco();
    String getDescricao();
}
